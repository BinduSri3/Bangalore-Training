package com.cg.hotel.dao;

public interface IQueryMapper {
	public static final String GET_AID="SELECT seq_appointment_id.CURRVAL FROM DUAL";
	public static final String GET_ALLHOTELS="SELECT * FROM RoomDetails";
}