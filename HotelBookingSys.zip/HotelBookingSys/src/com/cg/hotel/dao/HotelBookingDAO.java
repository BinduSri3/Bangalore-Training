package com.cg.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MPS.dao.IQueryMapper;
import com.capgemini.MPS.dto.MobilePurcahseSystemDTO;
import com.capgemini.MPS.exceptions.MobilePurchaseSystemException;
import com.cg.hotel.bean.CustomerDetails;
import com.cg.hotel.bean.RoomDetails;
import com.cg.hotel.exceptions.HotelBookingException;
import com.cg.hotel.util.DBConnection;


public class HotelBookingDAO implements IHotelBookingDAO 
{
	private Logger logger = Logger.getLogger(HotelBookingDAO.class);	
	public HotelBookingDAO()
	{
	PropertyConfigurator.configure("log4j.properties");
	}
	
	public List<RoomDetails> getRoomDetails() 
	{
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;		
		List<RoomDetails> customerList= new ArrayList<RoomDetails>();
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_ALLHOTELS);
			resultSet=preparedStatement.executeQuery();

			while(resultSet.next())
			{	
				RoomDetails bean=new RoomDetails();
				bean.setMobileId(resultSet.getInt(1));
				bean.setMobileName(resultSet.getString(2));
				bean.setMobilePrice(resultSet.getInt(3));
				bean.setQuantity(resultSet.getInt(4));
				customerList.add(bean);	
			}	
		}
		
		catch(MobilePurchaseSystemException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return customerList;
		
		
	}

	
	
	
}

