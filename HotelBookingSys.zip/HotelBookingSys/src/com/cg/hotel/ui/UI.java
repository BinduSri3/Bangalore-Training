package com.cg.hotel.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.hotel.bean.CustomerDetails;
import com.cg.hotel.bean.RoomDetails;
import com.cg.hotel.exceptions.HotelBookingException;
import com.cg.hotel.service.HotelBookingService;

/*
 * 
create table CustomerDetails(CustId number,CustName varchar2(25),Email varchar2(30),CustAddress varchar2(25),MobileNumber number(10),RoomType varchar2(15),RoomNo number(4) reference RoomDetails(RoomNo));


create table RoomDetails(RoomNo number(4) primary key,Roomtype varchar2(15),status varchar2(15));

create sequence CustomerID_seq start with 1000;



insert into RoomDetails values(101,'AC_SINGLE','Not Booked');
insert into RoomDetails  values(102,'AC_SINGLE','Not Booked');
insert into RoomDetails values(103,'AC_DOUBLE','Not Booked');
insert into RoomDetails values(201,'NONAC_SINGLE','Not Booked');
insert into RoomDetails values(202,'NONAC_SINGLE','Not Booked');
insert into RoomDetails values(203,'NONAC_DOUBLE','Not Booked');
insert into RoomDetails values(204,'AC_SINGLE','Not Booked');
*/





public class UI {
	private static Scanner in;
	static HotelBookingService service= new HotelBookingService();

	public static void main(String[] args) throws HotelBookingException {
		in = new Scanner(System.in);
		System.out.println("Welocome To Doctor Appointment portal");
		String choice = "null";
		
		while (!choice.equals("3")) {
			System.out.println("Enter your choice");
			System.out.println("1) Book Room ");
			System.out.println("2) View status ");
			System.out.println("3) EXIT ");
			choice = in.next().trim();
			switch (choice) 
			{
			case "1": 
					addDetails();
					break;
			case "2":
				getDetails();
				break;
		
			case "3":
				System.out.println("Thank you.... Program terminated");
				System.exit(0);
				break;
				
			default:
				System.out.println("WRONG CHOICE chosen...Please enter a valid choice");
			}
		}
		System.out.println("Thank you.... program terminated");
	}

	
	private static void addDetails() throws HotelBookingException 
	{
		CustomerDetails dtoOBJ = new CustomerDetails();
		HotelBookingService serv= new HotelBookingService();
		
		String Name="?";
		String mailId="?";
		String Adress="";
		String mobileNumber="?";
		String RoomType;
		int RoomNumber;
		boolean status=true;
		
		
		while(status)
		{
			System.out.println("Enter Customer Name");
			Name=in.next();
			if(serv.validateName(Name)==true)
			{
				status=false; break;
			}
			else
			{
			System.out.println("Name should start with captital letters.. enter again");
			}
		}
		
		status=true;

		while(status)
		{
			System.out.println("Enter Customer Mail id");
			mailId=in.next();
			if(serv.validateEmail(mailId)==true){
				status=false; break;
			}
			else
			{
			System.out.println("Wrong mail id given.. enter again");
			}
		}
		

		System.out.println("Enter Customer adress");
		Adress=in.next();
		
		status=true;
		while(status)
		{
			System.out.println("Enter Customer Mobile number");
			mobileNumber=in.next();
			if(serv.validatePhoneNumber(mobileNumber)==true){
				status=false; break;
			}
			else
			{
			System.out.println("Wrong mobile number given.. enter again");
			}
		}
		

		
		while(status)
		{
			System.out.println("Enter Room no");
			String roomNo=in.next();
			if(serv.validateRoomNumber(roomNo))
			{
				List<RoomDetails> rooms = serv.getRoomDetails();
				
			}
		}
		
		
		
		
		
		
	}
		
	

	private static void getDetails() throws HotelBookingException 
	{
	
		
	}
		
}
