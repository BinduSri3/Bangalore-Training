package com.cg.hotel.bean;

public class RoomDetails {
	int RoomNo;
	String Roomtype;
	String bookingStatus;
	
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public int getRoomNo() {
		return RoomNo;
	}
	public void setRoomNo(int roomNo) {
		RoomNo = roomNo;
	}
	public String getRoomtype() {
		return Roomtype;
	}
	public void setRoomtype(String roomtype) {
		Roomtype = roomtype;
	}
}
