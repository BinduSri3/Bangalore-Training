package com.cg.hotel.service;

import java.util.ArrayList;

import com.cg.hotel.bean.CustomerDetails;
import com.cg.hotel.exceptions.HotelBookingException;

public interface IHotelBookingService 
{
	
}
