package com.cg.hotel.service;


import java.util.List;
import java.util.regex.Pattern;

import com.cg.hotel.bean.CustomerDetails;
import com.cg.hotel.bean.RoomDetails;
import com.cg.hotel.dao.HotelBookingDAO;
import com.cg.hotel.exceptions.HotelBookingException;

public class HotelBookingService implements IHotelBookingService
{

	HotelBookingDAO Dao;;
	public HotelBookingService(){
		Dao = new HotelBookingDAO();
	}
	
	public boolean validateName(String str)
	{
    String namePattern = "[A-Z][A-Za-z ]{1,20}";
	if(Pattern.matches(namePattern,str))
	{
		return true;
	}
	else
	{
		return false;
	}
	}
	
	
	public boolean validateEmail(String str)
	{
		if(Pattern.matches("[A-Za-z0-9]{1,20}[@][A-Za-z]{1,15}[.][A-Za-z]{1,15}",str))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validatePhoneNumber(String str)
	{
		if(Pattern.matches("\\d{10}",str))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}

	public boolean validateRoomNumber(String roomNo) {
		// TODO Auto-generated method stub
		if(Pattern.matches("\\d{3}",roomNo))
		{
			return true;
		}
		else
		{
			return false;
		}		
	}

	public List<RoomDetails> getRoomDetails() {
		// TODO Auto-generated method stub
		return Dao.getRoomDetails();
	}
	
	
}
