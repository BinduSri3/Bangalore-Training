package com.cg.hotel.exceptions;

public class HotelBookingException extends Exception {
	public HotelBookingException(String msg)
	{
		super(msg);
	}
}
