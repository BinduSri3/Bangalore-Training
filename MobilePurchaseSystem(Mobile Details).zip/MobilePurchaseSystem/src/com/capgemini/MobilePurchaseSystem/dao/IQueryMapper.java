package com.capgemini.MobilePurchaseSystem.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="insert into purchaseDetails values(mpSequence.nextval,?,?,?,?,?)";
	public static final String GET_PID="SELECT mpSequence.CURRVAL FROM DUAL";
	public static final String GET_MobileId="select mobileid from mobiles";
	public static final String ALL_MobileDetails="SELECT * FROM mobiles";
}
