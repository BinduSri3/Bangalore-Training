package com.cg.tms.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.dao.TrainerDaoImpl;
import com.cg.tms.exception.TrainerManageException;

public class TrainerDaoTest {

	
	
	
	
	
	
	static TrainerDaoImpl dao;
	static TrainerDetails donor;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new TrainerDaoImpl();
		donor = new TrainerDetails();
	}

	@Test
	public void testAddTraineerDetails() throws TrainerManageException {

		assertNotNull(dao.addTrainerDetails(donor));

	}

	
	@Test
	public void testAddTrainerDetails1() throws TrainerManageException {
		// increment the number next time you test for positive test case
		donor.setContactNo("7893922340");
		donor.setDesignation("consultent");
		donor.setLocation("mumbai");
		donor.setId(143450);
		donor.setName("Murali");
		donor.setTechnology("jee");
		assertEquals(143450, dao.addTrainerDetails(donor));
	}

	
	
}
