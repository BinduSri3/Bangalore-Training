package com.cg.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerManageException;
import com.cg.tms.util.DBConnecton;

public class TrainerDaoImpl implements TrainerDao {
	
	static Connection conn;
	
	Logger logger=Logger.getRootLogger();
	public TrainerDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public int addTrainerDetails(TrainerDetails details)
			throws TrainerManageException {
		

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, details.getName());
			insertStmt.setString(2, details.getLocation());
			insertStmt.setString(3, details.getDesignation());
			insertStmt.setString(4, details.getTechnology());
			insertStmt.setString(5, details.getContactNo());
			

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				logger.error("Insertion failed ");
				throw new TrainerManageException("Sorry! insert not performed");
			} else {
				logger.info("Trainer details added successfully:");
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {
			logger.error(e.getMessage());
			throw new TrainerManageException(e.getMessage());
		}
int trainer = getTrainerId();
		return trainer;
	}
	
	@Override
	public int getTrainerId() throws TrainerManageException{
		
		PreparedStatement getTrainerStmt = null;
		ResultSet trainerIdResult = null;
		int trainerid = 0;
		try {
			conn = DBConnecton.getConnection();
			getTrainerStmt = conn.prepareStatement(IQueryMapper.GET_TRAINER_ID);
			trainerIdResult = getTrainerStmt.executeQuery();
			if (trainerIdResult.next()) {
				trainerid = trainerIdResult.getInt(1);
				logger.info("Registation done: " + trainerid);
			}
		} catch (TrainerManageException e) {
			logger.error(e.getMessage());
			throw new TrainerManageException("Sorry trainerid not genrated");
		} catch (SQLException e) {
			
			logger.error(e.getMessage());
			throw new TrainerManageException("Sorry trainerid sql exception genrated");

		}

		return trainerid;
		
		
	}
	
	

}
