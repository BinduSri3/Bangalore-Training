package com.cg.tms.service;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerManageException;

public interface TrainerService {
	public int addTrainerDetails(TrainerDetails details) throws TrainerManageException;
	boolean validateMobNumber(String PhoneNumber);
	boolean validateTrainerName(String trainer);

}
