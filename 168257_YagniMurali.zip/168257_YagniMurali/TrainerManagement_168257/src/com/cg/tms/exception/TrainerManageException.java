package com.cg.tms.exception;

public class TrainerManageException extends Exception{
	public TrainerManageException(String msg) {
		super(msg);
	}

}
