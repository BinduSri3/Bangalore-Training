/**
 * 
 */
package com.cg.model;
import java.time.LocalDateTime;

/**
 * @author Smita
 *
 */
public class MyClock{
	private LocalDateTime clock;
	public MyClock() {
		// TODO Auto-generated constructor stub
	}

	public LocalDateTime getClock() {
		return LocalDateTime.now();
	}

	public void setClock(LocalDateTime clock) {
		this.clock = clock;
	}
	
}
