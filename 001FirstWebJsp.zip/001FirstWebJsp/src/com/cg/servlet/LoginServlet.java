package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// step 1: get the request
		String strUser = request.getParameter("username");
		String strPass = request.getParameter("password");
		// step 2: set the contentType of response
		response.setContentType("text/html");// default response type is text
		// step 3: obtain the Writer to write the response
		PrintWriter pw = response.getWriter();
		// step 4:authenticate user and dispatch related specific response to other component
		RequestDispatcher rd = null;
		//HttpSession session = null;
		if((strUser.equals("111"))&&(strPass.equals("111"))) {
			//how to obtain the session
			HttpSession session= request.getSession();
			//server will start the session for the specific request if it is new
			//if the session for the request exists then it will continue the 
			//same session
			//getId - return the unique session id created by the server
			pw.println("<h3>Session Id :  !!"+session.getId()+"</h1>");	
			//lets set the session timeout programmatically
			session.setMaxInactiveInterval(10);//seconds
			
			rd= request.getRequestDispatcher("/welcome.jsp");
			pw.println("<h1 style='color:blue'>Login Successful !!</h1>");	
			rd.include(request, response);
		}
		else {
			rd= request.getRequestDispatcher("/login.jsp");
			pw.println("<h1 style='color:red'>Login Failed Kindly Re-Login!!</h1>");
			rd.include(request, response);
		}
		// close the writer
		pw.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
