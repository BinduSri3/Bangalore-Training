package com.cg.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class LifeCycleServlet
 */
//step 1: created a class and extended from either GenericServlet or HttpServlet
//step 2: Annotate the class with @WebServlet
//step 3: Override init method for initialization
//step 4: Override service or doGet/doPost methods for handling request/response
//step 5: Override destroy method for destruction/undeployment of the servlet
@WebServlet("/LifeCycleServlet")//published name of the servlet
//by which this servlet will be identified other to other web components
public class LifeCycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LifeCycleServlet() {
        super();
        System.out.println("1>Servlet instance created...Only Once");
    }
	public void init(ServletConfig config) throws ServletException {
		 System.out.println("2>Servlet init method invoked......Only Once");
	}
	public void destroy() {
		System.out.println("Last>Servlet destroy method invoked......Only Once");
	}
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("********For every request>Servive method invoked...");
	}
}
