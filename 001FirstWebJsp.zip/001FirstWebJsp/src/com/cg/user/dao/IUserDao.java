/**
 * 
 */
package com.cg.user.dao;

import java.util.List;

import com.cg.user.exception.MyUserException;
import com.cg.user.model.MyUser;

/**
 * @author Smita
 *
 */
public interface IUserDao {
	public int addUser(MyUser myUser)throws MyUserException;
	public List<MyUser> listAllUser()throws MyUserException;
	public boolean authenticateUser(MyUser myUser)throws MyUserException;
	
}
