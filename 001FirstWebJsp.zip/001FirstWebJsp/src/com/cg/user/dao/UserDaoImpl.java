/**
 * 
 */
package com.cg.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.user.exception.MyUserException;
import com.cg.user.model.MyUser;
import com.cg.user.util.DBConnection;
import com.cg.user.util.MyConnection;

/**
 * @author Smita drop table myusers1; create table myusers1 ( userId number
 *         primary key, username varchar2(30)not null, password varchar2(30)not
 *         null);
 * 
 *         drop sequence myusers1_seq; create sequence myusers1_seq start with
 *         1;
 * 
 *         insert into myusers1 values(myusers1_seq.nextval,'111','111'); insert
 *         into myusers1 values(myusers1_seq.nextval,'admin','admin'); insert
 *         into myusers1 values(myusers1_seq.nextval,'smita','smita'); commit;
 */
public class UserDaoImpl implements IUserDao {
	// prep work : conn
	private Connection conn;

	public UserDaoImpl() throws MyUserException {
		conn = MyConnection.getConnection();
	}

	@Override
	public int addUser(MyUser myUser) throws MyUserException {
		int result = 0;
		try {
			PreparedStatement preparedStatement = conn.prepareStatement(
			"insert into myusers1 values ((myusers_seq.nextval, ?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, myUser.getUsername());
			preparedStatement.setString(2, myUser.getPassword());
			result = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			throw new MyUserException("Error in UserDao addUser() -->" + e.getMessage());
		}
		return result;
	}

	@Override
	public List<MyUser> listAllUser() throws MyUserException {
		List<MyUser> myusers1 = new ArrayList<MyUser>();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from myusers1");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				MyUser myUser = new MyUser();
				myUser.setUsername(rs.getString("username"));
				myUser.setPassword(rs.getString("password"));
				myusers1.add(myUser);
			}
		} catch (SQLException e) {
			throw new MyUserException("Error in UserDao getAllUsers() -->" + e.getMessage());
		}
		return myusers1;
	}

	@Override
	public boolean authenticateUser(MyUser myUser) throws MyUserException {
		boolean result = false;
		try {
			PreparedStatement ps = conn.prepareStatement(
			"select username from myusers1 where username = ? and password=?");
			ps.setString(1, myUser.getUsername());
			ps.setString(2, myUser.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) // found
			{
				result = true;
			}
		} catch (Exception ex) {
			throw new MyUserException("Error in UserDao authenticateUser() -->" + ex.getMessage());
		}
		return result;
	}
	
	public int deleteUser(String username) throws MyUserException{
		int result=0;
		try {
			PreparedStatement preparedStatement = 
		conn.prepareStatement("delete from myusers1 where username=?");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			result=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new MyUserException("Error in UserDao deleteUser() -->" + e.getMessage());
		}
		return result;
	}

	
	public int updateUser(MyUser myUser)throws MyUserException {
		int result=0;
		try {
			PreparedStatement preparedStatement = conn
					.prepareStatement("update myusers1 set password=? where username=?");
			// Parameters start with 1
			preparedStatement.setString(1, myUser.getPassword());
			preparedStatement.setString(2, myUser.getUsername());
			result=preparedStatement.executeUpdate();

		} catch (SQLException e) {
			throw new MyUserException("Error in UserDao updateUser() -->" + e.getMessage());
		}
		return result;
	}
	
	public MyUser getUserById(String userId)throws MyUserException {
		MyUser myUser = new com.cg.user.model.MyUser();
		try {
			PreparedStatement preparedStatement = conn.prepareStatement(
					"select * from myusers1 where username=?");
			preparedStatement.setString(1, userId);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				myUser.setUsername(rs.getString("username"));
				myUser.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			throw new MyUserException("Error in UserService getUserById() -->" + e.getMessage());
		}

		return myUser;
	}
}
