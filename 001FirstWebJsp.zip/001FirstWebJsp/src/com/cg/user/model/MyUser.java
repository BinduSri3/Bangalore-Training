/**
 * 
 */
package com.cg.user.model;

/**
 * @author Smita
 *
 */
public class MyUser {
	private int userId;
	private String username;
	private String password;
	//generate constructors,getter,setters,toString
	public MyUser() {
		// TODO Auto-generated constructor stub
	}
	//no userId in overloaded constructor
	public MyUser(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "MyUser [userId=" + userId + ", username=" + username + ", password=" + password + "]";
	}
	
}
