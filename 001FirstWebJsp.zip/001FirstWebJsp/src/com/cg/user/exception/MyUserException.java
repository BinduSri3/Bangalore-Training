/**
 * 
 */
package com.cg.user.exception;

/**
 * @author Smita
 *
 */
public class MyUserException extends Exception {
	private static final long serialVersionUID = -989909217116382215L;

	public MyUserException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyUserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
