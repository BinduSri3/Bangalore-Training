package com.cg;

public class EmployeeInterfaceImpl implements EmployeeInterface{

	private Employee employee;
	private SBUbean sbu;
	
	public Employee getEmployee() {
		return this.employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	@Override
	public SBUbean getSBUdetails() {
		// TODO Auto-generated method stub
		return this.sbu;
	}
	

}
