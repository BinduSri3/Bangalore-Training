package com.cg;

public class EmployeeInterfaceImpl implements EmployeeInterface{

	private Employee employee;
	
	public Employee getEmployee() {
		return this.employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	

}
