package com.cg;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resource res = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		
		Employee emp = (Employee) factory.getBean("employee");
		
		System.out.println("Employee Detais");	
		System.out.println("---------------------------");
		System.out.println("Employee id             : " + emp.getEmployeeId() );
		System.out.println("Employee name           : " + emp.getEmployeeName() );
		System.out.println("Employee salary         : " + emp.getSalary() );
		System.out.println("Employee bussiness unit : " + emp.getBussinessUnit() );
		System.out.println("Employee age            : " + emp.getAge() );

	}
}
