package com.cg;

public interface EmployeeInterface {
	public Employee getEmployee();
}
