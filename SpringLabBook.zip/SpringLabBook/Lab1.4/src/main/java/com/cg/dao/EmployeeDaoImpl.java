package com.cg.dao;

public class EmployeeDaoImpl implements EmployeeDaoInterface 
{
   
}
