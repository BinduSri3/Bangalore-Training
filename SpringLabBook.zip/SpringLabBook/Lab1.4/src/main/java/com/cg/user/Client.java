package com.cg.user;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.EmployeeService.EmployeeServiceImpl;
import com.cg.dto.Employee;
import com.cg.dto.EmployeeCollection;

public class Client {

	public static void main(String[] args) {
		EmployeeServiceImpl service= new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		
		Resource res = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		
	EmployeeCollection empCollection =(EmployeeCollection) factory.getBean("Collection");
		
		System.out.println("Enter Employee Id:");
		int id= sc.nextInt();
		
		List<Employee> empList= empCollection.getEmployeeList();
		
		for(Employee e : empList )
		{
			if(e.getEmployeeId()==id)
			{
				System.out.println(e.toString());
				return;
			}
		}
		
		System.out.println("Thre are no employees with given id");
 		
	}
}
