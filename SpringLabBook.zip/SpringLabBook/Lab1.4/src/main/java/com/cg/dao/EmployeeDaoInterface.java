package com.cg.dao;

public interface EmployeeDaoInterface {

}
