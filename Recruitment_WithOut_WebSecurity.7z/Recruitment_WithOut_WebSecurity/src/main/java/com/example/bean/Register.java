package com.example.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.ColumnDefault;
import org.springframework.beans.factory.annotation.Value;
@Entity
public class Register {
	@Id
//@ColumnDefault("Candidate_Id")
private int candidateId;
@ColumnDefault("Admin")
@Column(name="Candidate_name")
private String candidateName;
@ColumnDefault("12/12/1995")
@Column(name="Dateofbirth")
private Date   dateOfBirth;
@ColumnDefault("Admin")
@Column(name="Qualification")
private String qualification;
@ColumnDefault("Admin")
@Column(name="Email_Id")
private String emailId;
@ColumnDefault("Admin")
@Column(name="password" )
private String password;
@ColumnDefault("Admin")
@Column(name="contact_number")
private String contactNo;
@Value(value="Admin")
@Column(name="gender")
private String gender;
@ColumnDefault("Admin")
private String contactNumber;
@ColumnDefault("User")
private String userType;
@Id
@GeneratedValue
public int getCandidateId() {
	return candidateId;
}
public void setCandidateId(int candidateId) {
	this.candidateId = candidateId;
}
public String getCandidateName() {
	return candidateName;
}
public void setCandidateName(String candidateName) {
	this.candidateName = candidateName;
}
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getContactNo() {
	return contactNo;
}
public void setContactNo(String contactNo) {
	this.contactNo = contactNo;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
/**
 * @return the userType
 */
public String getUserType() {
	return userType;
}
/**
 * @param userType the userType to set
 */
public void setUserType(String userType) {
	this.userType = userType;
}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "Register [candidateId=" + candidateId + ", candidateName=" + candidateName + ", dateOfBirth=" + dateOfBirth
			+ ", qualification=" + qualification + ", emailId=" + emailId + ", password=" + password + ", contactNo="
			+ contactNo + ", gender=" + gender + ", contactNumber=" + contactNumber + ", userType=" + userType + "]";
}

}
