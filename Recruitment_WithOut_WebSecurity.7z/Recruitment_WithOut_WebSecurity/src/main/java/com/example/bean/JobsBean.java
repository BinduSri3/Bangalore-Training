package com.example.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class JobsBean {

	private int jobId;
	private String JobTitle;
	private String qualification;
	private Date startDate;
	private Date lastDate;
	private String AgeLimit;
	private String jobLocation;
	private String organizationName;
	private String jobDescription;
	private String experience;
	private double jobSalary;
	private int numberOfVaccency;
	
	/**
	 * @return the jobSalary
	 */
	public double getJobSalary() {
		return jobSalary;
	}
	/**
	 * @param jobSalary the jobSalary to set
	 */
	public void setJobSalary(double jobSalary) {
		this.jobSalary = jobSalary;
	}
	
	/**
	 * @return the jobId
	 */
	@Id
	@GeneratedValue
	public int getJobId() {
		return jobId;
	}
	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	/**
	 * @return the jobTitle
	 */
	public String getJobTitle() {
		return JobTitle;
	}
	/**
	 * @param jobTitle the jobTitle to set
	 */
	public void setJobTitle(String jobTitle) {
		JobTitle = jobTitle;
	}
	/**
	 * @return the qualification
	 */
	public String getQualification() {
		return qualification;
	}
	/**
	 * @param qualification the qualification to set
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the lastDate
	 */
	public Date getLastDate() {
		return lastDate;
	}
	/**
	 * @param lastDate the lastDate to set
	 */
	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}
	/**
	 * @return the ageLimit
	 */
	public String getAgeLimit() {
		return AgeLimit;
	}
	/**
	 * @param ageLimit the ageLimit to set
	 */
	public void setAgeLimit(String ageLimit) {
		AgeLimit = ageLimit;
	}
	/**
	 * @return the jobLocation
	 */
	public String getJobLocation() {
		return jobLocation;
	}
	/**
	 * @param jobLocation the jobLocation to set
	 */
	public void setJobLocation(String jobLocation) {
		this.jobLocation = jobLocation;
	}
	/**
	 * @return the organizationName
	 */
	public String getOrganizationName() {
		return organizationName;
	}
	/**
	 * @param organizationName the organizationName to set
	 */
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	/**
	 * @return the jobDescription
	 */
	public String getJobDescription() {
		return jobDescription;
	}
	/**
	 * @param jobDescription the jobDescription to set
	 */
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	/**
	 * @return the experience
	 */
	public String getExperience() {
		return experience;
	}
	/**
	 * @param experience the experience to set
	 */
	public void setExperience(String experience) {
		this.experience = experience;
	}
	/**
	 * @return the numberOfVaccency
	 */
	public int getNumberOfVaccency() {
		return numberOfVaccency;
	}
	/**
	 * @param numberOfVaccency the numberOfVaccency to set
	 */
	public void setNumberOfVaccency(int numberOfVaccency) {
		this.numberOfVaccency = numberOfVaccency;
	}
	@Override
	public String toString() {
		return "JobsBean [jobId=" + jobId + ", JobTitle=" + JobTitle + ", qualification=" + qualification
				+ ", startDate=" + startDate + ", lastDate=" + lastDate + ", AgeLimit=" + AgeLimit + ", jobLocation="
				+ jobLocation + ", organizationName=" + organizationName + ", jobDescription=" + jobDescription
				+ ", experience=" + experience + ", jobSalary=" + jobSalary + ", numberOfVaccency=" + numberOfVaccency
				+ "]";
	}
	
}
