package com.recruitment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class RecruitmentSpringBootApplication {
	public static void main(String[] args) {
		
		SpringApplication.run(RecruitmentSpringBootApplication.class, args);
	}

}
