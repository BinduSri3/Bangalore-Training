package com.cg.trainerDto;

import java.util.Date;

public class TrainerDto {
	
	

}
