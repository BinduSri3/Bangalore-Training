package com.capgemini.trainer.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.trainer.dao.TrainerDaoimpl;
import com.capgemini.trainer.exceptions.TrainerException;
import com.capgemini.trainerDto.TrainerDto;

public class TrainerServiceImpl implements ITrainerService {
	TrainerDaoimpl TDao;

	// getdetails method

	

	public TrainerServiceImpl() {
		TDao = new TrainerDaoimpl();
	}

	@Override
	public boolean validatename(String str) {

		String namePattern = "[A-Z][A-Za-z]{5,20}";
		if (Pattern.matches(namePattern, str)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validatecontactNo(String str) {
		String namePattern = "[7-9][0-9]{9}";
		if (Pattern.matches(namePattern, str)) {
			return true;
		} else {
			return false;
		}
	}

/*	@Override
	public void setDetails(TrainerDto Tdto) {
		TrainerServiceImpl tdao=new TrainerServiceImpl();
		tdao.setDetails(Tdto);
		
	}
	*/
	
	public int getpid() throws TrainerException, SQLException {
		return TDao.getpid();
	}

	public TrainerDto addDetails(TrainerDto Tdto) throws TrainerException {
		// TODO Auto-generated method stub
		return TDao.addDetails(Tdto);
	}

}
