package com.capgemini.trainer.service;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.trainer.exceptions.TrainerException;
import com.capgemini.trainerDto.TrainerDto;


public interface ITrainerService {
	
	public boolean validatename(String str);
	public boolean validatecontactNo(String str);
	
	public TrainerDto addDetails(TrainerDto Tdto) throws TrainerException;
	//public void setDetails(TrainerDto Tdto);

}
