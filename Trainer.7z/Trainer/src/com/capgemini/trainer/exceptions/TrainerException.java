package com.capgemini.trainer.exceptions;

public class TrainerException extends Exception {
	public TrainerException(String msg) {
		super(msg);
	}
}
