package com.capgemini.trainer.presentation;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.trainer.dao.TrainerDaoimpl;
import com.capgemini.trainer.exceptions.TrainerException;
import com.capgemini.trainer.service.TrainerServiceImpl;
import com.capgemini.trainerDto.TrainerDto;

public class TrainerUI {
	static String name;
	static String location;
	static String designation;
	static String technology;
	static String contactNo;
	static boolean status = true;
	private static Scanner sc;

	// TrainerServiceImpl impl object
	

	public static void main(String[] args) throws TrainerException,
			SQLException {
		sc = new Scanner(System.in);
		System.out.println("Welcome to newly joined trainers");

		while (true) {
			System.out.println("Enter your choice");
			System.out.println("1) Insert Trainer Details ");
			System.out.println("2) EXIT ");
			String choice = sc.next();
			switch (choice) {
			case "1":
				getInputs();

				System.out.println("Welcome");
				break;

			case "2":
				System.out.println("Thank u!!!");
				System.exit(0);
				break;
			}
		}
	}

	private static void getInputs() throws TrainerException, SQLException {
		TrainerDto Tdto = new TrainerDto(); // create dto object
		TrainerDaoimpl daoobj = new TrainerDaoimpl(); // create dao impln object
		 TrainerServiceImpl ts = new TrainerServiceImpl();
		// validating trainer name
		while (status) {
			System.out.println("Enter Trainer Name");
			name = sc.next();
			if (ts.validatename(name) == true) {
				break;

			} else {
				System.out
						.println("Name should start with captital letters.. enter again");

			}
		}

		System.out.println("\nEnter your location");
		System.out.println("\n 1.Hyderabad");
		System.out.println("\n 2.Chennai");
		System.out.println("\n 3.Pune");
		System.out.println("\n 4.Bangalore");
		System.out.println("\n 5.Mumbai");
		String loc = null;
		while (true) {
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				location = "Hyderabad";
				break;

			case 2:
				location= "Chennai";
				break;

			case 3:
				location = "Pune";
				break;

			case 4:
				location= "Banglore";
				break;

			case 5:
				location= "Mumbai";
				break;

			default:
				System.out.println("Enter valid option");

			}
			
			if (choice <= 5 && choice > 0) {
				break;
			}

		}
		System.out.println("\n Choose your designation");
		System.out.println("\n 1.consultant");
		System.out.println("\n 2.senior consultant");

		while (status) {
			int des = sc.nextInt();
			switch (des) {
			case 1:
				designation="consultant";
				break;
			case 2:
				designation ="senior consultant";

			default:
				System.out.println("Invalid option");
			}
			Tdto.setDesignation(designation);
			if (des <= 2 && des > 0) {
				break;
			}
		}

		System.out.println("\n Choose your Technology");
		System.out.println("\n 1.jee");
		System.out.println("\n 2.cloud");
		System.out.println("\n 3.mainframes");

		while (status) {
			int tech = sc.nextInt();
			switch (tech) {
			case 1:
				technology ="jee";
				break;
			case 2:
				technology="cloud";
				break;
			case 3:
				technology ="mainframes";

			default:
				System.out.println("enter valid option");
			}
			
			if (tech <= 3 && tech > 0) {
				break;
			}
		}

		// validating contact number

		while (status) {
			System.out.println("Enter Contact No");
			contactNo = sc.next();
			if (ts.validatecontactNo(contactNo) == true) {
				status = true;
				break;
			} else {
				System.out.println("Wrong mail id given.. enter again");

			}
		}
		

	
			// calling dto object and set the data 

			Tdto.setName(name);
			Tdto.setLocation(location);
			Tdto.setDesignation(designation);
			Tdto.setTechnology(technology);
			Tdto.setContactNo(contactNo);
			System.out.println(name);
			System.out.println(location);
			System.out.println(designation);
			System.out.println(technology);
			System.out.println(contactNo);
			ts.addDetails(Tdto);
			
		
			System.out
					.println("\n****All details updated successfully11111*****");

			System.out.println("your id is "+ts.getpid());

			
		}

	}



