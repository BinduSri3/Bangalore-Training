package com.capgemini.trainer.dao;

import java.util.ArrayList;

import com.capgemini.trainer.exceptions.TrainerException;
import com.capgemini.trainerDto.TrainerDto;

public interface TrainerDao {
	/*public TrainerDto getdetails(TrainerDto dtoobj)throws TrainerException;*/
	public TrainerDto addDetails(TrainerDto Tdto) throws TrainerException;
	

}
