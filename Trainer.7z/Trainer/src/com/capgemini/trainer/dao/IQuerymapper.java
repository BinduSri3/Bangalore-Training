package com.capgemini.trainer.dao;

public interface IQuerymapper {
	public static final String INSERT_QUERY = "insert into trainer_details values( Trainer_Id_Seq1.nextval,?,?,?,?,?)";
	public static final String GET_PID = "SELECT Trainer_Id_Seq1.CURRVAL FROM DUAL";
}
