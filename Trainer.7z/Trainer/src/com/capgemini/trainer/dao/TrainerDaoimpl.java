package com.capgemini.trainer.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.trainer.exceptions.TrainerException;
import com.capgemini.trainer.util.DBConnection;
import com.capgemini.trainerDto.TrainerDto;

public class TrainerDaoimpl implements TrainerDao {

	// dto object
	private Logger logger = Logger.getLogger(TrainerDaoimpl.class); // logger
																	// file

	public TrainerDaoimpl() {
		PropertyConfigurator.configure("log4j.properties");

	}

	@Override
	public TrainerDto addDetails(TrainerDto Tdto) throws TrainerException {
		logger.info("Customer registration started");
		Connection con;
		PreparedStatement insertStmt = null;
		con = DBConnection.getConnection();

		try {

			insertStmt = con.prepareStatement(IQuerymapper.INSERT_QUERY);

			// insertStmt.setString(1, Tdto.getPurchaseId());

			// enter the values in console.set by using bean obj and get the
			// info from bean in daoimpln cls .
			// next set the info to database
			insertStmt.setString(1, Tdto.getName());
			insertStmt.setString(2, Tdto.getLocation());
			insertStmt.setString(3, Tdto.getDesignation());
			insertStmt.setString(4, Tdto.getTechnology());
			insertStmt.setString(5, Tdto.getContactNo());

			/*
			 * System.out.println(Tdto.getContactNo());
			 * System.out.println(Tdto.getDesignation());
			 * System.out.println(Tdto.getLocation());
			 * System.out.println(Tdto.getTechnology());
			 * System.out.println(Tdto.getName());
			 */

			int result = insertStmt.executeUpdate();
			if (result != 1) {
				logger.error("Insertion failed ");
				throw new TrainerException("Sorry not inserted!!!");
			} else {
				// insertStmt = con
				// .prepareStatement(IQuerymapper.Get_updateQuantity);
				con.commit();
			}
		} catch (SQLException | NullPointerException e) {
			e.printStackTrace();
		}

		logger.info("details inserted  successfully:");
		return Tdto;

	}

	public int getpid() throws TrainerException, SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int id = 0;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerymapper.GET_PID);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				id = resultSet.getInt(1);
			}

		} catch (TrainerException e) {
			logger.info("Unable to fetch ur Id");
			throw new TrainerException("soory not fetching the Id");

		}
		return id;
	}

}
