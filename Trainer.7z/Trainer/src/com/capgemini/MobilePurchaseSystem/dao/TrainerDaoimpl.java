package com.capgemini.MobilePurchaseSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MobilePurchaseSystem.exceptions.TrainerException;
import com.capgemini.MobilePurchaseSystem.util.DBConnection;
import com.cg.trainerDto.TrainerDto;

public class TrainerDaoimpl implements TrainerDao {

	TrainerDto customerMps = new TrainerDto();
	private Logger logger = Logger.getLogger(TrainerDaoimpl.class); //logger file

	public TrainerDaoimpl() {
		PropertyConfigurator.configure("log4j.properties");
	}

	
}
