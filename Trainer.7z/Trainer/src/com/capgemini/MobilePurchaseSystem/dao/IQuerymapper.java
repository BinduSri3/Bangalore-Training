package com.capgemini.MobilePurchaseSystem.dao;

public interface IQuerymapper {
	
}
