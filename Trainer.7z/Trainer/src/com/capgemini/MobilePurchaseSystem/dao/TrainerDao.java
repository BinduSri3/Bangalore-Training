package com.capgemini.MobilePurchaseSystem.dao;

import java.util.ArrayList;

import com.capgemini.MobilePurchaseSystem.exceptions.TrainerException;
import com.cg.trainerDto.TrainerDto;

public interface TrainerDao {

}
