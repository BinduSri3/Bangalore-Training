package com.capgemini.MobilePurchaseSystem.presentation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.MobilePurchaseSystem.exceptions.TrainerException;
import com.capgemini.MobilePurchaseSystem.service.TrainerServiceImpl;
import com.cg.trainerDto.TrainerDto;

public class TrainerUI {
	String customerName;
	private static Scanner sc;
	private static long transcID = 1234001;
	static TrainerServiceImpl mp = new TrainerServiceImpl();

	public static void main(String[] args)
			throws TrainerException, SQLException {
		sc = new Scanner(System.in);
		System.out.println("Welcome to Mobile Purchase Store");
		String choice;
		while (true) {
			System.out.println("\n Enter your choice");
			System.out.println("1. Enter purchase details");
			System.out.println("2. Display the available mobiles");
			System.out.println("3.Search the mobile Range");
			System.out.println("4: Enter an mobile id to Delete");
			System.out.println("5.Exit");
			choice = sc.next().trim();
			switch (choice) {
			case "1":
				//getPurchaseDetails();
				break;
			case "2":
				//getMobileDetails();
				break;
			case "3":
				getSearchedMobiles();
				break;
			case "4":
				deleteRecord();
			case "5":
				System.out.println("\n \n Thank u!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Choose valid choice");
				break;
			}
		}
	}

	public static void deleteRecord() throws TrainerException {
	

	}

	public static void getSearchedMobiles() {
	}

}
