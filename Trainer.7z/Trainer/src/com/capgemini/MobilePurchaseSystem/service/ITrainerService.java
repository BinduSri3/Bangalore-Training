package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.MobilePurchaseSystem.exceptions.TrainerException;
import com.cg.trainerDto.TrainerDto;

public interface ITrainerService {

	

}
