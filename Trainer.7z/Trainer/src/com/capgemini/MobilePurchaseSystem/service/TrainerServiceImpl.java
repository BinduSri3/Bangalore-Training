package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.MobilePurchaseSystem.dao.TrainerDaoimpl;
import com.capgemini.MobilePurchaseSystem.exceptions.TrainerException;
import com.cg.trainerDto.TrainerDto;

public class TrainerServiceImpl implements
		ITrainerService {
	TrainerDaoimpl mpDao;

	public TrainerServiceImpl() {
		mpDao = new TrainerDaoimpl();
	}

	

}
