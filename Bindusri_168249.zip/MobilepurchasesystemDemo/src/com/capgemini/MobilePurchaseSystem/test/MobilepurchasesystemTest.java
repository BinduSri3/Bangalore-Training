package com.capgemini.MobilePurchaseSystem.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.junit.*;

import com.capgemini.MobilePurchaseSystem.dao.MobilepurchasesystemDaoImpl;
import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilepurchasesystemException;

public class MobilepurchasesystemTest {

	static CustomerDto customerMps;
	static MobilepurchasesystemDaoImpl mpDao;

	@BeforeClass
	public static void setuptest1() {
		mpDao = new MobilepurchasesystemDaoImpl();
	}

	@AfterClass
	public static void setuptest2() {
		mpDao = null;
	}

	@After
	public void setuptest3() {
		customerMps = null;
	}

	@Before
	public void setUPtest() throws Exception {
		customerMps = new CustomerDto();
	}

	@Test
	public void setCustomerTest() throws Exception {
		Date d = new Date();
		customerMps.setCustomerName("HelloBindu");
		customerMps.setMailId("Bindu543@gmail.com");
		customerMps.setPhoneNumber("9087642335");
		customerMps.setPurchaseDate(d);
		customerMps.setMobileId(1002);
		try {
			String name = mpDao.mobilePurchaseSystem(customerMps)
					.getPurchaseId();
			Assert.assertNotSame(0, name);
		} catch (MobilepurchasesystemException e) {
			Assert.fail();
		}
	}

	@Test
	public void Test6() throws MobilepurchasesystemException {
		ArrayList<CustomerDto> sm = new ArrayList<CustomerDto>();
		CustomerDto sm1 = new CustomerDto();
		sm1.setMobileId(1002);
		sm1.setMobileName("Samsung Galaxy IV");
		sm1.setPrice(38000);
		sm1.setQuantity(39);
		sm = mpDao.getSearchedMobiles(30000, 40000);
		if (sm != null) {
			Iterator<CustomerDto> i = sm.iterator();
			while (i.hasNext()) {
				CustomerDto obj = (CustomerDto) i.next();
				// Assert.assertNotSame(obj,sm1);
				Assert.assertNotSame(0, obj.getMobileId());
				Assert.assertNotSame("samsung", obj.getMobileName());
				Assert.assertNotSame(35000, obj.getPrice());
				Assert.assertNotSame(28, String.valueOf(obj.getQuantity()));
			}
		}
	}
}
