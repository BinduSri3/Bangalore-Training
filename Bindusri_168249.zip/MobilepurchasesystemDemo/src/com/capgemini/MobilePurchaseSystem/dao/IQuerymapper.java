package com.capgemini.MobilePurchaseSystem.dao;

public interface IQuerymapper {
	public static final String INSERT_QUERY="insert into purchaseDetails values(mpSequence.nextval,?,?,?,?,?)";
	public static final String GET_PID="SELECT mpSequence.CURRVAL FROM DUAL";
	public static final String GET_MobileId="select mobileid from mobiles";
	public static final String ALL_MobileDetails="SELECT * FROM mobiles";
	public static final String Get_SearchedMobiles="Select * from mobiles where price between ? and ?";
	public static final String Get_updateQuantity="update mobiles set quantity = (quantity - 1) where mobileID = ?";
	public static final String Get_Quantity = "select quantity from mobiles where mobileId = ?";
	public static final String DELETERecords="Delete from mobiles where mobileid =?";
}

