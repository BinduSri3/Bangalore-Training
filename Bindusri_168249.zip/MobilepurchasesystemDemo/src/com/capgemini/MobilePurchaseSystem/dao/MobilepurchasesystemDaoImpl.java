package com.capgemini.MobilePurchaseSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilepurchasesystemException;
import com.capgemini.MobilePurchaseSystem.util.DBConnection;

public class MobilepurchasesystemDaoImpl implements ImobilepurchasesystemDao {

	CustomerDto customerMps = new CustomerDto();
	private Logger logger = Logger.getLogger(MobilepurchasesystemDaoImpl.class);

	public MobilepurchasesystemDaoImpl() {
		PropertyConfigurator.configure("log4j.properties");
	}

	/*******************************************************************************************************
	  - Function Name     : mobilePurchaseSystem(CustomerDto customerMps)
	  - Input Parameters  : CustomerDto customerMps 
	  - Return Type       : CustomerDto 
	  - Throws            : MobilePurchaseSystemException 
	  - Author            : CAPGEMINI 
	  - Creation Date 	  : 27/01/2019 
	  - Description       : Inserting a purchase details
	 ********************************************************************************************************/

	@Override
	public CustomerDto mobilePurchaseSystem(CustomerDto customerMps)
			throws MobilepurchasesystemException {

		logger.info("Customer registration started");
		Connection con;
		PreparedStatement insertStmt = null;
		con = DBConnection.getConnection();
		try {
			java.util.Date udate = customerMps.getPurchaseDate();
			java.sql.Date sdate = new java.sql.Date(udate.getTime());

			insertStmt = con.prepareStatement(IQuerymapper.INSERT_QUERY);
			// insertStmt.setString(1, customerMps.getPurchaseId());
			insertStmt.setString(1, customerMps.getCustomerName());
			insertStmt.setString(2, customerMps.getMailId());
			insertStmt.setString(3, customerMps.getPhoneNumber());
			insertStmt.setDate(4, sdate);
			insertStmt.setLong(5, customerMps.getMobileId());
			int result = insertStmt.executeUpdate();
			if (result != 1) {
				logger.error("Insertion failed ");
				throw new MobilepurchasesystemException("Sorry not inserted!!!");
			} else {
				insertStmt = con
						.prepareStatement(IQuerymapper.Get_updateQuantity);
				insertStmt.setLong(1, customerMps.getMobileId());
				result = insertStmt.executeUpdate();
				con.commit();
			}
		} catch (SQLException | NullPointerException e) {
			e.printStackTrace();
		}
		logger.info("details inserted  successfully:");
		return customerMps;
	}

	/*******************************************************************************************************
	 - Function Name 	: getPID() 
	 - Input Parameters : 
	 - Return Type 		: integer
	  -Throws 			: MobilePurchaseSystemException 
	  - Author 			: CAPGEMINI 
	  - CreationDate 	: 27/01/2019
	   - Description 	: Fetching the purchase Id
	 ********************************************************************************************************/
	public int getPID() throws MobilepurchasesystemException, SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int purchaseID = 0;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQuerymapper.GET_PID);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				purchaseID = resultSet.getInt(1);
			}

		} catch (MobilepurchasesystemException e) {
			logger.info("Unable to fetch the purchase Id");
			throw new MobilepurchasesystemException(
					"soory not fetching the Purchase Id");

		}
		return purchaseID;
	}

	// for mobile id
	/*******************************************************************************************************
	 	- Function Name 	: getMobileId() 
	 	- Input Parameters 	: 
	 	- Return Type 		: List
	 	- Throws 			: MobilePurchaseSystemException 
	 	- Author 			: CAPGEMINI 
	 	- Creation Date 	: 27/01/2019 - Description : Fetching the available mobile Id's
	 ********************************************************************************************************/
	public ArrayList<Long> getMobileId() throws SQLException,
			MobilepurchasesystemException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<Long> list = new ArrayList<Long>();

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQuerymapper.GET_MobileId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				list.add(resultSet.getLong("mobileid"));
			}

		} catch (MobilepurchasesystemException e) {
			logger.info("Unable to fetch the Mobile Id");
			throw new MobilepurchasesystemException(
					"soory not fetching the Mobile Id");

		}
		return list;
	}

	// list mobiles
	/*******************************************************************************************************
	  - Function Name 		: getAllMobiles() 
	  - Input Parameters 	: 
	  - Return Type 		: List 
	  - Throws 				: MobilePurchaseSystemException 
	  - Author 				: CAPGEMINI 
	  - Creation Date 		: 27/01/2019 
	  - Description 		: displaying all the mobile details
	 ********************************************************************************************************/
	public ArrayList<CustomerDto> getAllMobiles()
			throws MobilepurchasesystemException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		ArrayList<CustomerDto> customerList = new ArrayList<CustomerDto>();
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQuerymapper.ALL_MobileDetails);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				CustomerDto bean = new CustomerDto();
				bean.setMobileId(resultSet.getInt(1));
				bean.setMobileName(resultSet.getString(2));
				bean.setPrice(resultSet.getInt(3));
				bean.setQuantity(resultSet.getInt(4));
				customerList.add(bean);
			}
		} catch (MobilepurchasesystemException e) {
			throw new MobilepurchasesystemException("sorry not updated");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new MobilepurchasesystemException("sorry not updated");
		}
		return customerList;
	}

	// mobiles within the range
	/*******************************************************************************************************
	  - Function Name 		: getSearchedMobiles(int min, int max) 
	  - Input Parameters	: int,int 
	  - Return Type			: List 
	  - Throws 				: MobilePurchaseSystemException 
	  - Author 				: CAPGEMINI 
	  - Creation Date		: 27/01/2019 
	  - Description 		: displaying all the mobile details within the given Range
	 ********************************************************************************************************/

	public ArrayList<CustomerDto> getSearchedMobiles(int min, int max) {
		ArrayList<CustomerDto> mlist = new ArrayList<CustomerDto>();
		Connection conn;
		PreparedStatement preparedStatement;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQuerymapper.Get_SearchedMobiles);
			preparedStatement.setInt(1, min);
			preparedStatement.setInt(2, max);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				CustomerDto bin = new CustomerDto();
				bin.setMobileId(rs.getInt(1));
				bin.setMobileName(rs.getString(2));
				bin.setPrice(rs.getLong(3));
				bin.setQuantity(rs.getInt(4));
				mlist.add(bin);
			}
			preparedStatement.close();
		} catch (Exception e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}

		return mlist;
	}

	/*******************************************************************************************************
	  - Function Name 		: isThere(long mobileId) 
	  - Input Parameters 	: long mobileId 
	  - Return Type 		: boolean 
	  - Throws 				: MobilePurchaseSystemException
	  - Author 				: CAPGEMINI 
	  - Creation Date 		: 27/01/2019 
	  - Description 		: To check whether quantity is greater than 0
	 ********************************************************************************************************/

	public boolean isThere(long mobileId) {
		Connection conn;
		PreparedStatement preparedStatement;
		int mobiles = 0;
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQuerymapper.Get_Quantity);
			preparedStatement.setLong(1, mobileId);
			ResultSet set = preparedStatement.executeQuery();
			while (set.next()) {
				mobiles = set.getInt(1);
			}
			if (mobiles > 0) {
				return true;
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return false;
	}
	/*******************************************************************************************************
	  - Function Name : delRecordsSql(int del) 
	  - Input Parameters : int del
	  - Return Type : int 
	  - Throws : MobilePurchaseSystemException
	  - Author : CAPGEMINI 
	  - Creation Date : 27/01/2019 
	  - Description : Deleting a record based on mobileId
	 ********************************************************************************************************/

	public int delRecordsSql(int del) throws MobilepurchasesystemException {
		Connection conn = DBConnection.getConnection();
		PreparedStatement preDel = null;
		try {
			preDel = conn.prepareStatement(IQuerymapper.DELETERecords);
			preDel.setInt(1, del);
			int result = preDel.executeUpdate();
			if (result != 1) {
				logger.debug("Deletion failed");
				throw new MobilepurchasesystemException("Deletion failed");
			} else {
				conn.close();
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return del;

	}

}
