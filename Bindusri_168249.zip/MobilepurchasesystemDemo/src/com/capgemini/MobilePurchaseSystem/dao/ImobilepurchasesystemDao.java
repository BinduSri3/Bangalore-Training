package com.capgemini.MobilePurchaseSystem.dao;

import java.util.ArrayList;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilepurchasesystemException;

public interface ImobilepurchasesystemDao {

	
	public CustomerDto mobilePurchaseSystem(CustomerDto mps)throws MobilepurchasesystemException;
	public ArrayList<CustomerDto> getAllMobiles()
			throws MobilepurchasesystemException;
	public ArrayList<CustomerDto> getSearchedMobiles(int min, int max);
}


