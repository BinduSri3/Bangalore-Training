package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilepurchasesystemException;

public interface IMobilepurchasesystemService {
	
	public CustomerDto mobilePurchaseSystem(CustomerDto cusdto) throws MobilepurchasesystemException;
	
	 boolean ValidateCustomerName(String custerName);
	 boolean ValidateMailId(String mailId);
	 boolean ValidatePhoneNumber(String phoneNum);
	 boolean ValidateMobileId(long mobileId);
	 boolean ValidatePurchaseId(String purchaseId);
	//abstract boolean ValidatePurchaseDate();
	 public int getPID() throws MobilepurchasesystemException, SQLException;
	 public ArrayList<Long> getMobileId() throws SQLException, MobilepurchasesystemException;
	 public ArrayList<CustomerDto> getAllMobiles()throws MobilepurchasesystemException;
	 public ArrayList<CustomerDto> getSearchedMobiles(int min, int max);
	 public void delRecord(int del) throws MobilepurchasesystemException;
		 
}
