package com.capgemini.MobilePurchaseSystem.exceptions;

public class MobilepurchasesystemException extends Exception{
	public  MobilepurchasesystemException (String msg){
		super(msg);
	}
}
