package com.capgemini.MobilePurchaseSystem.presentation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilepurchasesystemException;
import com.capgemini.MobilePurchaseSystem.service.MobilepurchasesystemServiceImpl;

public class UserInterface {
	String customerName;
	private static Scanner sc;
	private static long transcID = 1234001;
	static MobilepurchasesystemServiceImpl mp = new MobilepurchasesystemServiceImpl();

	public static void main(String[] args)
			throws MobilepurchasesystemException, SQLException {
		sc = new Scanner(System.in);
		System.out.println("Welcome to Mobile Purchase Store");
		String choice;
		while (true) {
			System.out.println("\n Enter your choice");
			System.out.println("1. Enter purchase details");
			System.out.println("2. Display the available mobiles");
			System.out.println("3.Search the mobile Range");
			System.out.println("4: Enter an mobile id to Delete");
			System.out.println("5.Exit");
			choice = sc.next().trim();
			switch (choice) {
			case "1":
				getPurchaseDetails();
				break;
			case "2":
				getMobileDetails();
				break;
			case "3":
				getSearchedMobiles();
				break;
			case "4":
				deleteRecord();
			case "5":
				System.out.println("\n \n Thank u!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Choose valid choice");
				break;
			}
		}
	}

	public static void deleteRecord() throws MobilepurchasesystemException {
		System.out.println("Enter Id to delete");
		int del=sc.nextInt();
		mp.delRecord(del);
		
	}

	public static void getSearchedMobiles() {
		System.out.println("Enter Minimum price range");
		int min = sc.nextInt();
		System.out.println("Enter Maximum price range");
		int max = sc.nextInt();
		ArrayList<CustomerDto> range = new ArrayList<CustomerDto>();
		range = mp.getSearchedMobiles(min, max);
		System.out.println("MobileID  MobileName  MobilePrice  MobileQuantity");
		if (range != null) {
			Iterator<CustomerDto> i = range.iterator();
			while (i.hasNext()) {
				CustomerDto obj = (CustomerDto) i.next();
				System.out.print(obj.getMobileId() + "  ");
				System.out.print(obj.getMobileName() + "  ");
				System.out.print(obj.getPrice() + "  ");
				System.out.print(obj.getQuantity() + "  " + "\n");
			}
			System.out.println();
		} else {
			System.out.println("There are no mobiles in the store");
		}

	}

	public static void getMobileDetails() throws MobilepurchasesystemException {
		List<CustomerDto> mobilesList = new ArrayList<CustomerDto>();
		mobilesList = mp.getAllMobiles();
		System.out.println("========Mobile Details========");
		if (mobilesList != null) {
			Iterator<CustomerDto> i = mobilesList.iterator();

			while (i.hasNext()) {
				CustomerDto obj = (CustomerDto) i.next();

				System.out.print(obj.getMobileId() + "  ");
				System.out.print(obj.getMobileName() + "  ");
				System.out.print(obj.getPrice() + "  ");
				System.out.print(obj.getQuantity() + "  " + "\n");
			}
		} else {
			System.out.println("There are no mobiles in the store");
		}
	}

	public static void getPurchaseDetails()
			throws MobilepurchasesystemException, SQLException {
		String customerName = "";
		String customerMail = "";
		String phoneNo = "";
		long mobileId = 0;
		// String purchaseId = "";
		Date puchaseDate = new Date();

		CustomerDto customerMps = new CustomerDto();
		boolean status = true;

		// Customer Nmae
		int count = 3;
		while (status) {
			System.out.println("Enter customer Name");
			customerName = sc.next();

			if (mp.ValidateCustomerName(customerName) == true) {
				System.out.println("welcome to customer");
				break;
			} else {
				System.out.println("invalid customer name");
				count--;
				if (count == 0)
					status = false;
			}
		}
		// Mail Id
		count = 3;
		while (status) {
			System.out.println("Enter customer mail id");
			customerMail = sc.next();

			if (mp.ValidateMailId(customerMail) == true) {
				break;
			} else {
				System.out.println("invalid customer mail");
				count--;
				if (count == 0)
					status = false;
			}
		}
		// phone Numebr
		count = 3;
		while (status) {
			System.out.println("Enter Phone Number");
			phoneNo = sc.next();

			if (mp.ValidatePhoneNumber(phoneNo) == true) {
				break;
			} else {
				System.out.println("invalid phone Number");
				count--;
				if (count == 0)
					status = false;
			}
		}
		// mobile ID
		count = 3;
		while (status) {
			ArrayList<Long> mobilelist = new ArrayList<Long>();
			mobilelist = mp.getMobileId();
			System.out.println("available mobile IDs:" + mobilelist);
			System.out.println("Enter mobile Id");
			mobileId = sc.nextLong();
			if (mp.ValidateMobileId(mobileId) == true) {
				if (mobilelist.contains(mobileId)){
						if(mp.isThere(mobileId)){
							break;
						}else{
							System.out.println("Stock Not avialable");
						}
				}
				else {
					System.out
							.println("Enter only valid mobile ids in th list");
				}
			} else {
				System.out.println("invalid mobile Id");
				count--;
				if (count == 0)
					status = false;
			}
		}

		// purchase Id
		/*
		 * count = 3; while(status) { System.out.println("Enter purchase Id");
		 * purchaseId = sc.next();
		 * 
		 * if (mp.ValidateMobileId(purchaseId) == true) { break; } else{
		 * System.out.println("invalid purchase Id"); count--; if(count == 0)
		 * status = false; } }
		 */
		if (status == true) {
			// customerMps.setPurchaseId(purchaseId);
			customerMps.setCustomerName(customerName);
			customerMps.setMailId(customerMail);
			customerMps.setPhoneNumber(phoneNo);
			customerMps.setPurchaseDate(puchaseDate);
			customerMps.setMobileId(mobileId);

			customerMps = mp.mobilePurchaseSystem(customerMps);

			System.out.println("Successfully entered");
			System.out.println(customerMps.getCustomerName() + "\n"
					+ customerMps.getMailId() + "\n"
					+ customerMps.getPhoneNumber() + "\n"
					+ customerMps.getMobileId() + "\n"
					+ customerMps.getPurchaseDate() + "\n");
			System.out.println("Transcation comnpleted\n Your Transaction id is"
					+ transcID++);
			System.out.println("Your purchase ID is " + mp.getPID());
			System.out.println("\n");
		}

		else
			System.out.println("U r Terminated");

	}

}
