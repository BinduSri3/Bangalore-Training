package com.cg.app.Repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.app.Entities.Transactions;

public interface TransactionRepository extends JpaRepository<Transactions,Integer> {
//
//	List<Transactions> findByFrmCard(int accountId);
	List<Transactions> findByAccountId(int accountId);

	@Query("select tr from Transactions tr where tr.dateOfTransaction=:TransactionDate and tr.accountId=:accountId")
	public Transactions getTransactions(@Param("TransactionDate") Date transactionDate,@Param("accountId") int accountId);



	

	

}
