package com.cg.app.Service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.Customer;
import com.cg.app.Entities.Transactions;
import com.cg.app.Repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository crepos;

	/*************** post service *************/

	public Customer addCustomer(Customer cust) {
		return crepos.save(cust);
	}

	/*************** GET service *************/

	public List<Customer> getAllCustomers() {

		return crepos.findAll();
	}

	public Customer getcustomerdetails(int accountId) {
		if (ValiadatecustId(accountId))
			return crepos.getOne(accountId);
		else
			return null;
	}

	private boolean ValiadatecustId(int accountId) {
		Customer cust = crepos.findOne(accountId);
		if (cust != null)
			return true;
		else
			return false;
	}

	/*************** DELETE Service *************/

	public void deleteCustomerDetails(int accountId) {

		if (validateAccNo(accountId))
			crepos.delete(accountId);
	}

	public boolean validateAccNo(int accountId) {
		Customer customer = crepos.findOne(accountId);
		if (customer != null)
			return true;
		else
			return false;
	}

	/*********************** UPDATE Service *********************/

	public Customer updateCustomer(Customer customer) {

		return crepos.save(customer);
	}

	/***********************************************/
	
	public double getBalance(int accountId) {
		if (validateAccNo(accountId))
			return crepos.findOne(accountId)
					.getBalance();
		else
			return (Double) null;

	}

	

}
