package com.cg.app.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.FundTransfer;
import com.cg.app.Entities.Payee;
import com.cg.app.Entities.Transactions;
import com.cg.app.Repository.AccountMasterRepository;
import com.cg.app.Repository.CustomerRepository;
import com.cg.app.Repository.FundTransferRepository;
import com.cg.app.Repository.PayeeRepository;
import com.cg.app.Repository.TransactionRepository;

@Service
public class FundTransferService {

	@Autowired
	private FundTransferRepository fundTransferRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private PayeeRepository payeeRepository;

	@Autowired
	AccountMasterRepository accountMasterRepository;

	public boolean validateFundTransferPayeeId(int payeeId) {
		Payee payee = payeeRepository.findOne(payeeId);
		if (payee != null)
			return true;
		else
			return false;
	}

	public List<Transactions> addfundtransfer(FundTransfer fundtransfer) {

		AccountMaster payeebalance=accountMasterRepository.findOne(fundtransfer.getFundTransferPayeeId());
		AccountMaster customerBalance=accountMasterRepository.findOne(fundtransfer.getAccountId());
		
		Double credit =   payeebalance.getAccountBalance();
		payeebalance.setAccountBalance(credit+fundtransfer.getTransferAmount());
		accountMasterRepository.save(payeebalance);
		
		Double debit = customerBalance.getAccountBalance();
		customerBalance.setAccountBalance(debit-fundtransfer.getTransferAmount());
		accountMasterRepository.save(customerBalance);
		
		
		Transactions payeeTransactions= new Transactions();
		Transactions customerTransactions = new Transactions();
		
		payeeTransactions.setAccountId(fundtransfer.getFundTransferPayeeId());
		payeeTransactions.setDateOfTransaction(new Date());
//		payeeTransactions.setTranAmount(100.09);
		payeeTransactions.setTranAmount(fundtransfer.getTransferAmount());
		payeeTransactions.setTrandescription("credited......");
		payeeTransactions.setTransactionType("credit");
		
		customerTransactions.setAccountId(fundtransfer.getAccountId());
		customerTransactions.setDateOfTransaction(new Date());
//		customerTransactions.setTranAmount(5000.089);
		customerTransactions.setTranAmount(fundtransfer.getTransferAmount());
		customerTransactions.setTrandescription("debited......");
		customerTransactions.setTransactionType("debit");		
		
		transactionRepository.save(customerTransactions);
		
		transactionRepository.save(payeeTransactions);
		
		fundtransfer.setDateofTransfer(new Date());
		fundTransferRepository.save(fundtransfer);
	
		List<Transactions> transactioList= new ArrayList<>();
		transactioList.add(customerTransactions);
		transactioList.add(payeeTransactions);
		
		return transactioList;

	}


	
	}
