package com.cg.app.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Payee;
import com.cg.app.Repository.AccountMasterRepository;
import com.cg.app.Repository.CustomerRepository;
import com.cg.app.Repository.PayeeRepository;

@Service
public class PayeeService {

	@Autowired
	private AccountMasterRepository arepos;
	@Autowired
	private PayeeRepository payeerepos;

	public Payee addpayee(Payee payee) {

		return payeerepos.save(payee);
	}

//***********************Get Method*****************************************//
	public List<Payee> getAllPayees() {

		return payeerepos.findAll();
	}

}
