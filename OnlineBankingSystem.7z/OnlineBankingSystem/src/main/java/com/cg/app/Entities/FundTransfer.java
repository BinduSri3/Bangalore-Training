package com.cg.app.Entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class FundTransfer {

	@Id
	@SequenceGenerator(name = "seq", sequenceName = "seq", initialValue = 100000, allocationSize = 50000)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fundTransferId;
	
	private int accountId;
	private int fundTransferPayeeId;

	public int getFundTransferPayeeId() {
		return fundTransferPayeeId;
	}

	public void setFundTransferPayeeId(int fundTransferPayeeId) {
		this.fundTransferPayeeId = fundTransferPayeeId;
	}

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "accountId", insertable=false, updatable=false)
	private AccountMaster accountMaster;

	private Date dateofTransfer;
	private Double transferAmount;

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "payeeId")
	private Payee payee;

	public int getFundTransferId() {
		return fundTransferId;
	}

	public void setFundTransferId(int fundTransferId) {
		this.fundTransferId = fundTransferId;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public AccountMaster getAccountMaster() {
		return accountMaster;
	}

	public void setAccountMaster(AccountMaster accountMaster) {
		this.accountMaster = accountMaster;
	}

	public Date getDateofTransfer() {
		return dateofTransfer;
	}

	public void setDateofTransfer(Date dateofTransfer) {
		this.dateofTransfer = dateofTransfer;
	}

	public Double getTransferAmount() {
		return transferAmount;
	}

	public void setTransferAmount(Double transferAmount) {
		this.transferAmount = transferAmount;
	}

	public Payee getPayee() {
		return payee;
	}

	public void setPayee(Payee payee) {
		this.payee = payee;
	}
}
