package com.cg.app.Entities;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

	@Entity
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@SequenceGenerator(name="seqT",sequenceName = "seqT", initialValue= 100, allocationSize=5000)
	public class Transactions {
		@Id	
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqT")
		
		private int transactionId;
		private String transDesc;
		private LocalDateTime transDate;
		private String transType;
		private int  transAmt;
		private int accountNo;
		
		public int getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}
		public String getTransDesc() {
			return transDesc;
		}
		public void setTransDesc(String transDesc) {
			this.transDesc = transDesc;
		}
		public LocalDateTime getTransDate() {
			return transDate;
		}
		public void setTransDate(LocalDateTime transDate) {
			this.transDate = transDate;
		}
		public String getTransType() {
			return transType;
		}
		public void setTransType(String transType) {
			this.transType = transType;
		}
		public int getTransAmt() {
			return transAmt;
		}
		public void setTransAmt(int transAmt) {
			this.transAmt = transAmt;
		}
		
		public int getAccountNo() {
			return accountNo;
		}
		public void setAccountNo(int accountNo) {
			this.accountNo = accountNo;
		}
		
		

	
}
