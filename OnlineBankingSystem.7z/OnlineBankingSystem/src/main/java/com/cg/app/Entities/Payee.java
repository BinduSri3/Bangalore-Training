package com.cg.app.Entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Payee {

	@Id
	private int payeeId;

	private int custId;

	private String nickname;
	private String ifscCode;

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "payeeId", insertable = false, updatable = false)
	private AccountMaster accountmaster;

//	@ManyToOne(cascade = CascadeType.PERSIST)
//	@JoinColumn(name = "customerAccountid", insertable = false, updatable = false)
//	private AccountMaster customer;

	
	public List<FundTransfer> getFundtransfer() {
		return fundtransfer;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public void setFundtransfer(List<FundTransfer> fundtransfer) {
		this.fundtransfer = fundtransfer;
	}

//	public AccountMaster getCustomer() {
//		return customer;
//	}
//
//	public void setCustomer(AccountMaster customer) {
//		this.customer = customer;
//	}
	@JsonIgnore
	@OneToMany(mappedBy = "payee")
	private List<FundTransfer> fundtransfer;

	public int getPayeeId() {
		return payeeId;
	}

	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public AccountMaster getAccountmaster() {
		return accountmaster;
	}

	public void setAccountmaster(AccountMaster accountmaster) {
		this.accountmaster = accountmaster;
	}

}
