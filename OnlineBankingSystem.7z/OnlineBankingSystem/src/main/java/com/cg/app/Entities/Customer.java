package com.cg.app.Entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Customer {

	@Id
	@SequenceGenerator(name = "seq", sequenceName = "seq", initialValue = 100000, allocationSize = 100001)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int custId;
	private String customerName;
	private String email;
	private String address;
	private String pancard;
	private String mobilenumber;
@JsonIgnore
	@OneToMany(mappedBy = "customer")
	private List<AccountMaster> accmaster;
	
//	@OneToMany(mappedBy= "customer")
//	private List<Payee> payees;

	public List<AccountMaster> getAccmaster() {
		return accmaster;
	}

	public void setAccmaster(List<AccountMaster> accmaster) {
		this.accmaster = accmaster;
	}

//	public List<Payee> getPayees() {
//		return payees;
//	}
//
//	public void setPayees(List<Payee> payees) {
//		this.payees = payees;
//	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPancard() {
		return pancard;
	}

	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

}
