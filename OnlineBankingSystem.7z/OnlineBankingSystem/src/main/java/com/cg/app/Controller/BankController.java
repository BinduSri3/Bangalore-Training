package com.cg.app.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.Entities.AccountMaster;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.FundTransfer;
import com.cg.app.Entities.Payee;
import com.cg.app.Entities.Transactions;
import com.cg.app.Service.AccountMasterService;
import com.cg.app.Service.CustomerService;
import com.cg.app.Service.FundTransferService;
import com.cg.app.Service.PayeeService;
import com.cg.app.Service.TransactionService;

@RestController
public class BankController {

	@Autowired
	private CustomerService cservice;

//	/************************ Create a new Account upon request *****************/

	/********************** Customer **********************************/

		/************ GET Method *************/

	@RequestMapping("/customer")
	public List<Customer> getAllCustomers() {
		return cservice.getAllCustomers();
	}

//	/*************** POST method *************/

	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer cust) {
		return cservice.addCustomer(cust);

	}

	/*--------- Updating of AccountHolder details based on Id------------ */

	@RequestMapping(value = "/customer/{custId}", method = RequestMethod.PUT)
	public Customer updateCustomer(@RequestBody Customer customer, @PathVariable int custId) {
		return cservice.updateCustomer(customer, custId);
	}

	// *************************************AccountMaster**************************************************///

	@Autowired
	private AccountMasterService aservice;

///*************** POST method *************/

	@RequestMapping(value = "/account", method = RequestMethod.POST)
	public AccountMaster addacc(@RequestBody AccountMaster accmaster) {
		return aservice.addacc(accmaster);

	}

///************ GET Method *************/

	@RequestMapping("/accountmaster")
	public List<AccountMaster> getAllAccounts() {
		return aservice.getAllAccounts();
	}

	@RequestMapping(value = "/accountmaster/{accountId}", method = RequestMethod.GET)
	public AccountMaster getaccountdetails(@PathVariable int accountId) {
		return aservice.getaccountdetails(accountId);
	}

///************************************************** payee*******************************************************/

	@Autowired
	private PayeeService pservice;

	@RequestMapping(value = "/addPayee", method = RequestMethod.POST)
	public Payee addpayee(@RequestBody Payee payee) {
		return pservice.addpayee(payee);

	}

	@RequestMapping("/payee")
	public List<Payee> getAllPayees() {
		return pservice.getAllPayees();
	}

	/*********************************************************************************************************/

	@Autowired
	private FundTransferService tservice;

	@RequestMapping(value = "/payee/{payeeId}/Transfer", method = RequestMethod.POST)
	public List<Transactions> addfundtransfer(@RequestBody FundTransfer fundTransfer) {
		return tservice.addfundtransfer(fundTransfer);

	}
/************************************************************************************************************************/
	
	/**gives list of transaction given the account number*/
	
	@Autowired
	private TransactionService transservice;
	
	@RequestMapping(value= "/accountMaster/{accountId}/transaction" ,method=RequestMethod.GET) 
	public List<Transactions> getAllTransactions(@PathVariable int accountId){
		return transservice.getAllTransactions(accountId);
	}
	
	@RequestMapping(value= "/accountMaster/{accountId}/{date}" ,method=RequestMethod.GET) 
	public Transactions getTransactionsByDate(@PathVariable Date  transactionDate,@PathVariable("accountId") int accountId){
		return transservice.getTransactions(transactionDate,accountId);
	}
}
