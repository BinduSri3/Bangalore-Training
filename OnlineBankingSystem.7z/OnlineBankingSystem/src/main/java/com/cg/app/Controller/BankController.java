package com.cg.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.app.Entities.Customer;
import com.cg.app.Entities.Transactions;
import com.cg.app.Service.CustomerService;

@RestController
public class BankController {

	@Autowired
	private CustomerService cservice;

	/********************* Create a new Account upon request *****************/

		/*************** post method *************/

	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public Customer addCustomer(@RequestBody Customer cust) {
		return cservice.addCustomer(cust);

	}

	/************ Get Method *************/

	@RequestMapping("/customer")
	public List<Customer> getAllCustomers() {
		return cservice.getAllCustomers();
	}

	@RequestMapping(value = "/customer/{accountId}", method = RequestMethod.GET)
	public Customer getcustomerdetails(@PathVariable int accountId) {
		return cservice.getcustomerdetails(accountId);
	}

	/************ Delete method *******************/

	@RequestMapping(value = "/deletecustomer/{accountId}", method = RequestMethod.DELETE)
	public void deleteCustomerDetails(@PathVariable int accountId) {
		cservice.deleteCustomerDetails(accountId);

	}

	/********** update method ******************/

	
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Customer updateCustomer(@RequestBody Customer customer) {
		return cservice.updateCustomer(customer);
	}

	/***********************************************/
	
	@RequestMapping("/balance/{accountId}")    
	public double getBalance(@PathVariable int accountId){
		return cservice.getBalance(accountId);
		} 
	
	//*************************************Transaction Calls**************************************************///
	
	
}
