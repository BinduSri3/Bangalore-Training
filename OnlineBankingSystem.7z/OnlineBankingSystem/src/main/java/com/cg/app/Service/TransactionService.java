package com.cg.app.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Entities.Customer;
import com.cg.app.Entities.Transactions;
import com.cg.app.Repository.CustomerRepository;
import com.cg.app.Repository.PayeeRepository;
import com.cg.app.Repository.TransactionRepository;

@Service
public class TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private PayeeRepository prepo;

	public boolean validateAccNo(int accountId) {
		Customer customer = customerRepository.findOne(accountId);
		if (customer != null)
			return true;
		else
			return false;
	}
	public List<Transactions> getAllTransactions(int accountId) {
		return transactionRepository.findByAccountId(accountId);

	}
	
	public Transactions getTransactions(Date transactionDate,int accountId) {
		return transactionRepository.getTransactions(transactionDate,accountId);
	}
}
	
	
//	public List<Transactions> getAllTransactions(int accountId) {
//
//		if(validateAccNo(accountId)) {
//
//			List<Transactions> listOfcreditTransaction = transactionRepository.findByFrmCard(accountId);
//			List<Transactions> listOfdebitTransaction = transactionRepository.findByFrmCard(accountId);
//
//			List<Transactions> listOfTransactions = new ArrayList<Transactions>();
//			listOfTransactions.addAll( listOfcreditTransaction);
//			listOfTransactions.addAll( listOfdebitTransaction); 
//
//			return listOfTransactions; 
//
//		} 
//
//		else 
//			return null;
//
//	}
	
	
	

	
