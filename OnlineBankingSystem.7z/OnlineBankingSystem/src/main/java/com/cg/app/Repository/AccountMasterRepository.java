package com.cg.app.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.app.Entities.AccountMaster;


public interface AccountMasterRepository extends JpaRepository<AccountMaster, Integer>{

	@Transactional
	@Query("Select accountBalance from AccountMaster a where a.custId=?1")
	int getAccountBalance(int custId);
}
