package com.cg.servlet;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class LifeCycleServlet
 */
//step 1: created a class and extends from either GenericServlet or Httpservlet
//step 2: Annotate the class with @WebServlet
//step 3: Override init method for initialization
//step 4: override service or doGet/doPost methods for handling request/response
//step5: override destroy method for destruction/undeployment of the servlet
@WebServlet("/LifeCycleServlet") //published nameof the servlet
//by which this servlet will be identified other to other web components
public class LifeCycleServlet extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
    public LifeCycleServlet() {
        super();
        // TODO Auto-generated constructor stub
        System.out.println("1)Servlet instance created...Only once");
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("2)Servlet init method invoked....");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("Last)Servlet destroy method invoked.....Only Once");
	}

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("********* For every request>Servive method invoked...");
	}

}
